# Bharat-Intern_Task-1
📈 Stock Price Prediction with LSTM 🚀  In this project, I had the exciting opportunity to dive into the world of stock market analysis and prediction using the Long Short-Term Memory (LSTM) model. 
Technologies Used for this project, I primarily utilized the following tools and technologies:
Python for data preprocessing, manipulation, visualization, and model implementation.
Jupyter Notebook as the coding environment for interactive development.
Keras library to build and train the LSTM model.
